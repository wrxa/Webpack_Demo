import React from 'react';
import { render } from 'react-dom';
import ShowSXBackgroud from './ShowSXBackgroud';
import './main.css';
// Import bootstrap css
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap';
import 'react';
import 'react-dom';
// Import jqeury

render( < ShowSXBackgroud / >, document.getElementById('showSXBackgroudButtonText'));