/**
 * let
 */
//test1
//var 与 let的区别。
{
  let x = 1;
  var y = 2;
  console.log("let:" + x);
}
console.log("let:" + x);
console.log("var:" + y);

//test2
//var的BUG
{
  var a = [];
  for (var i = 0; i < 10; i++) {
    //箭头函数
    a[i] = () => {
      console.log(i);
    };
    //   //常规写法
    //   a[i] = function(){
    //   console.log(i);
    //   }
  }
  a[6]();
}

/**
 * const
 */
//如果再次修改 PI的值就会报错。
//和let一样。是块级作用域的。
{
  const PI = 3.1415;
}
//保证的不是变量不变。而是内存地址不变。
{
  const foo = {};

  foo.prop = 123;

  //foo = {};
}
{
  const a = [];
  a.push("hello");
  a.length = 0;

  a = ["Dave"];
}

/**
 * set  & for..of
 */
//ES6 提供了新的数据结构 Set。它类似于数组，但是成员的值都是唯一的，没有重复的值
{
  const s = new Set();

  [2, 3, 5, 4, 5, 2, 2].forEach(x => s.add(x));

  for (let i of s) {
    console.log(i);
  }
  // 2 3 5 4
}
