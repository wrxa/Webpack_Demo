import React from 'react';
import { render } from 'react-dom';
import BaiduDemo from './BaiduDemo.jsx';
import './main.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap';

render(<BaiduDemo/>,document.getElementById('app'));