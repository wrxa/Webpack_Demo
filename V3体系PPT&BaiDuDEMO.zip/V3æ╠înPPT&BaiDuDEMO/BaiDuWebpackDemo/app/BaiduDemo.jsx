//create by ZPM
import React, { Component } from "react";
import config from "./config.json";
import "./BaiduDemo.css";

export default class BaiduDemo extends Component {

  //构造函数
  constructor(props) {
    super(props);
    //设置状态
    this.state = {
      clickdoBaidu: false,
    };
  }

  render() {

    let imgUrl = config.baiduLogoImgUrl;
    let buttonName = config.baiduButtonText;
    let clickdoBaidu = this.state.clickdoBaidu;
  
    return (
      <div>
        <div id="topLeft">
          <a href="http://news.baidu.com" name="tj_trnews" className="mnav">
            新闻
          </a>
          <a href="https://www.hao123.com" name="tj_trhao123" className="mnav">
            hao123
          </a>
          <a href="http://map.baidu.com" name="tj_trmap" className="mnav">
            地图
          </a>
          <a href="http://v.baidu.com" name="tj_trvideo" className="mnav">
            视频
          </a>
          <a href="http://tieba.baidu.com" name="tj_trtieba" className="mnav">
            贴吧
          </a>
          <a href="http://xueshu.baidu.com" name="tj_trxueshu" className="mnav">
            学术
          </a>
          <a
            href="https://passport.baidu.com/v2/?login&amp;tpl=mn&amp;u=http%3A%2F%2Fwww.baidu.com%2F&amp;sms=5"
            name="tj_login"
            className="login"
          >
            登录
          </a>
          <a
            href="http://www.baidu.com/gaoji/preferences.html"
            name="tj_settingicon"
            className="setting"
          >
            设置
          </a>
          <a
            href="http://www.baidu.com/more/"
            name="tj_briicon"
            className="more"
          >
            更多产品
          </a>
        </div>

        <div className="container col-md-6 ">
          <div>
            <img src={imgUrl} className="logoImg" />
          </div>
          <div className="formIn" >
            <input id="inputData" className="form-control" type="text"  onKeyPress={this.keypress.bind(this)} defaultValue="" autoFocus/>
             {/*不建议通过这种方式进行跳转。而是要使用react的router功能在getQueryLink中跳转*/}
            <a href={clickdoBaidu ? this.getQueryLink() : false}>
              <button
                id="doBaidu"
                className="btn btn-info pull-right"
                type="button"
                onClick={this.doBaidu.bind(this)}
              >
                {buttonName}
              </button>
            </a>
          </div>
        </div>
      </div>
    );
  }

  getQueryLink(){

    let queryString = document.getElementById("inputData").value;
    let baiduQureyUrl = config.baiduQureyUrl;
    let queryLink = baiduQureyUrl+queryString;
    if (queryString =="")
        return config.mainUrl;
    else
    return queryLink;
  }

  doBaidu() {
    //setState()是异步的。
    this.setState({ clickdoBaidu: true });
  }

  keypress(e){
    if (e.which !== 13) return;
    //同理。不建议使用这种方式跳转。而是使用router。
    window.location.href = this.getQueryLink();
  }
}
